"""
train_umbrella.py
-----------------
Şemsiye gerekliliği (umbrella_needed) ikili sınıflandırma modeli.

Düzeltmeler:
  1. Feature Engineering: weather_condition, climate_zone gibi kategorik sütunlar
     otomatik algılanıp OneHotEncoder ile modele ekleniyor.
  2. Data Leakage: Rastgele split YOK. Tarihe göre 70/15/15 temporal split uygulandı.
"""

import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report, f1_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

DATA_PATH = "ml/data/raw/hourly_observations.csv"
MODEL_PATH = "ml/trained_models/umbrella_model.pkl"
SCHEMA_PATH = "ml/trained_models/umbrella_feature_schema.json"
METRICS_PATH = "ml/trained_models/umbrella_metrics.json"

TARGET = "umbrella_needed"
RANDOM_STATE = 42

# ID / metin / diğer hedef sütunlar — özellik olarak kullanılmaz.
DROP_COLUMNS = [
    "obs_id",
    "timestamp",
    "date",
    "recommendation_headline",
    "recommendation_text",
    "clothing_recommendation",
    "outdoor_suitability_score",
    TARGET,
]


def _build_preprocessor(
    num_cols: list[str], cat_cols: list[str]
) -> ColumnTransformer:
    """Sayısal + kategorik sütunlar için ayrı pipeline döner."""
    num_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
    ])
    cat_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        # handle_unknown="ignore" → eğitimde görülmeyen kategoriler sıfır vektörü alır
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    return ColumnTransformer(
        transformers=[
            ("num", num_pipe, num_cols),
            ("cat", cat_pipe, cat_cols),
        ],
        remainder="drop",
    )


def _choose_best_threshold(
    y_true: pd.Series, probas: pd.Series
) -> tuple[float, float]:
    """Dev seti üzerinde F1'i maksimize eden karar eşiğini bulur."""
    best_thr, best_f1 = 0.50, -1.0
    for step in range(5, 96):
        thr = step / 100
        preds = (probas >= thr).astype(int)
        score = f1_score(y_true, preds, zero_division=0)
        if score > best_f1:
            best_f1, best_thr = score, thr
    return best_thr, best_f1


def _temporal_split(
    df: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Zaman damgasına göre 70 / 15 / 15 bölme.
    Veri sızıntısını önler: model hiçbir zaman 'geleceği' görmez.
    """
    n = len(df)
    train_end = int(n * 0.70)
    dev_end = int(n * 0.85)
    if train_end == 0 or dev_end <= train_end or dev_end >= n:
        raise ValueError("Veri seti 70/15/15 temporal bölme için çok küçük.")
    return df.iloc[:train_end], df.iloc[train_end:dev_end], df.iloc[dev_end:]


def run() -> dict:
    """Modeli eğitir, kaydeder ve metrik sözlüğü döner."""
    df = pd.read_csv(DATA_PATH)
    if TARGET not in df.columns:
        raise ValueError(f"Hedef sütun '{TARGET}' bulunamadı: {DATA_PATH}")

    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = (
        df.dropna(subset=["timestamp", TARGET])
        .sort_values("timestamp")
        .reset_index(drop=True)
    )

    df_train, df_dev, df_test = _temporal_split(df)

    def split_xy(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
        x = frame.drop(columns=[c for c in DROP_COLUMNS if c in frame.columns])
        y = frame[TARGET].astype(int)
        return x, y

    x_train, y_train = split_xy(df_train)
    x_dev, y_dev = split_xy(df_dev)
    x_test, y_test = split_xy(df_test)

    # --- Feature Engineering ---
    # Kategorik sütunlar otomatik algılanır (weather_condition, climate_zone vb.)
    cat_cols: list[str] = x_train.select_dtypes(
        include=["object", "string", "category"]
    ).columns.tolist()
    num_cols: list[str] = [c for c in x_train.columns if c not in cat_cols]

    print(f"  [Umbrella] Sayısal özellikler ({len(num_cols)}): {num_cols}")
    print(f"  [Umbrella] Kategorik özellikler ({len(cat_cols)}): {cat_cols}")

    preprocessor = _build_preprocessor(num_cols, cat_cols)
    clf = Pipeline([
        ("preprocess", preprocessor),
        ("model", RandomForestClassifier(
            n_estimators=600,
            max_depth=None,
            min_samples_leaf=1,
            class_weight="balanced_subsample",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        )),
    ])

    clf.fit(x_train, y_train)

    # Dev seti → eşik ayarı
    dev_probas = pd.Series(clf.predict_proba(x_dev)[:, 1])
    best_thr, best_dev_f1 = _choose_best_threshold(y_dev, dev_probas)

    # Test seti → nihai değerlendirme
    test_probas = clf.predict_proba(x_test)[:, 1]
    test_preds = (test_probas >= best_thr).astype(int)
    test_f1 = f1_score(y_test, test_preds, zero_division=0)

    print(f"  [Umbrella] Dev F1 (en iyi): {best_dev_f1:.4f}  (eşik={best_thr:.2f})")
    print(f"  [Umbrella] Test F1: {test_f1:.4f}")
    print(classification_report(y_test, test_preds, zero_division=0))

    # Son artifact: train + dev üzerinde yeniden eğitim
    x_td = pd.concat([x_train, x_dev], ignore_index=True)
    y_td = pd.concat([y_train, y_dev], ignore_index=True)
    clf.fit(x_td, y_td)

    Path("ml/trained_models").mkdir(parents=True, exist_ok=True)
    joblib.dump(clf, MODEL_PATH)

    schema = {
        "target": TARGET,
        "features": x_train.columns.tolist(),
        "numeric_features": num_cols,
        "categorical_features": cat_cols,
        "decision_threshold": best_thr,
        "split_strategy": "temporal_70_15_15",
    }
    with open(SCHEMA_PATH, "w", encoding="utf-8") as f:
        json.dump(schema, f, indent=2, ensure_ascii=False)

    metrics = {
        "dev_f1_best": best_dev_f1,
        "test_f1": test_f1,
        "decision_threshold": best_thr,
        "rows_train": len(df_train),
        "rows_dev": len(df_dev),
        "rows_test": len(df_test),
        "positive_rate_train": float(y_train.mean()),
        "positive_rate_test": float(y_test.mean()),
    }
    with open(METRICS_PATH, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)

    print(f"  [Umbrella] Model → {MODEL_PATH}")
    return metrics


if __name__ == "__main__":
    run()
